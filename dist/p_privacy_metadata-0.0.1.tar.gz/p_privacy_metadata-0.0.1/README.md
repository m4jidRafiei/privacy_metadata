Project that implements privacy metadata in process mining.
